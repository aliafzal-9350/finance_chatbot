"""
MongoDB Database Handler (READ-ONLY)
Industrial-grade connection with error handling and validation

Compatible with:
- finance chatbot/test_system.py
- app.py

Config keys expected (from config.py):
- Config.MONGO_URI
- Config.DATABASE_NAME
- Config.INVOICE_COLLECTION
- Config.LINE_ITEMS_COLLECTION
"""

from __future__ import annotations

from typing import Dict, List, Optional

import pandas as pd
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError

from config import Config


class DatabaseHandler:
    """Safe, read-only MongoDB operations"""

    def __init__(self):
        self.client: Optional[MongoClient] = None
        self.db = None

    def connect(self) -> bool:
        """
        Establish connection to MongoDB (Atlas or local)
        Returns: True if successful, False otherwise
        """
        try:
            # Validate configuration early
            try:
                Config.validate()
            except Exception as e:
                # Keep going, but surface the warning
                print(f"⚠️ Configuration validation warning: {e}")

            # Connect with timeouts (Atlas-friendly)
            self.client = MongoClient(
                Config.MONGO_URI,
                serverSelectionTimeoutMS=10_000,
                connectTimeoutMS=10_000,
                socketTimeoutMS=20_000,
                retryWrites=True,
            )

            # Verify connection (forces initial handshake)
            # server_info() can be slower; ping is usually quicker.
            self.client.admin.command("ping")

            # Access database
            self.db = self.client[Config.DATABASE_NAME]

            print(f"✅ Connected to MongoDB: {Config.DATABASE_NAME}")
            return True

        except ServerSelectionTimeoutError:
            print("❌ MongoDB connection timeout.")
            print("   - If using MongoDB Atlas: check Network Access (IP allowlist).")
            return False

        except ConnectionFailure as e:
            print(f"❌ Connection failed: {e}")
            return False

        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return False

    def get_invoices(self, limit: Optional[int] = None) -> pd.DataFrame:
        """
        Fetch all invoices (READ-ONLY)

        Args:
            limit: Maximum number of documents to fetch

        Returns:
            DataFrame with invoice data
        """
        try:
            if self.db is None:
                raise RuntimeError("Database not connected. Call connect() first.")

            collection = self.db[Config.INVOICE_COLLECTION]

            cursor = collection.find({})

            if limit:
                cursor = cursor.limit(limit)

            data = list(cursor)

            if not data:
                print("⚠️ No invoices found")
                return pd.DataFrame()

            # Remove Mongo _id (optional but recommended)
            for d in data:
                d.pop("_id", None)

            df = pd.DataFrame(data)
            print(f"✅ Loaded {len(df):,} invoices")

            return df

        except Exception as e:
            print(f"❌ Error fetching invoices: {e}")
            return pd.DataFrame()

    def get_line_items(self, invoice_ids: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Fetch invoice line items (READ-ONLY)

        Args:
            invoice_ids: Optional list of invoice IDs to filter

        Returns:
            DataFrame with line item data
        """
        try:
            if self.db is None:
                raise RuntimeError("Database not connected. Call connect() first.")

            collection = self.db[Config.LINE_ITEMS_COLLECTION]

            query = {}
            if invoice_ids:
                query = {"INVOICE_ID": {"$in": invoice_ids}}

            data = list(collection.find(query))

            if not data:
                print("⚠️ No line items found")
                return pd.DataFrame()

            for d in data:
                d.pop("_id", None)

            df = pd.DataFrame(data)
            print(f"✅ Loaded {len(df):,} line items")

            return df

        except Exception as e:
            print(f"❌ Error fetching line items: {e}")
            return pd.DataFrame()

    def get_collection_stats(self) -> Dict:
        """Get database statistics (used by test_system.py)"""
        try:
            if self.db is None:
                raise RuntimeError("Database not connected. Call connect() first.")

            stats = {
                "invoices_count": self.db[Config.INVOICE_COLLECTION].count_documents({}),
                "line_items_count": self.db[Config.LINE_ITEMS_COLLECTION].count_documents({}),
                "database_name": Config.DATABASE_NAME,
            }
            return stats

        except Exception as e:
            print(f"❌ Error getting stats: {e}")
            return {}

    def close(self):
        """Close database connection"""
        if self.client:
            self.client.close()
            self.client = None
            self.db = None
            print("✅ Database connection closed")