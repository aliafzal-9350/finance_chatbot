import pymongo
from datetime import datetime

# Connect to local MongoDB
try:
    client = pymongo.MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=5000)
    
    # Test connection
    client.server_info()
    print("✅ MongoDB connection successful!")
    
    # Connect to your database
    db = client["Zatca"]
    
    # List all collections
    print("\n📂 Collections in Zatca database:")
    collections = db.list_collection_names()
    for col in collections:
        count = db[col].count_documents({})
        print(f"  - {col}: {count:,} documents")
    
    # Show sample invoice (REPLACE 'invoices' with your actual collection name)
    # TODO: You need to tell me the collection name
    collection_name = "invoices"  # ⚠️ UPDATE THIS
    
    print(f"\n📄 Sample document from {collection_name}:")
    sample = db[collection_name].find_one()
    
    if sample:
        print("\nFields available:")
        for key in sample.keys():
            print(f"  - {key}")
    else:
        print("❌ No documents found. Check collection name!")
    
except pymongo.errors.ServerSelectionTimeoutError:
    print("❌ Could not connect to MongoDB.")
    print("Make sure MongoDB is running on localhost:27017")
except Exception as e:
    print(f"❌ Error: {e}")