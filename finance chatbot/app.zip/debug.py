"""
Quick debug script to check Status field values
"""
from database import DatabaseHandler
import pandas as pd

db = DatabaseHandler()
db.connect()
df_raw = db.get_invoices()
db.close()

print("=" * 60)
print("DATABASE STATUS FIELD ANALYSIS")
print("=" * 60)

# Check if Status field exists
if 'Status' in df_raw.columns:
    print("\n✅ 'Status' field found")
    print("\nUnique Status values:")
    print(df_raw['Status'].value_counts())
    print(f"\nTotal invoices: {len(df_raw)}")
    print(f"\nData type: {df_raw['Status'].dtype}")
    
    # Show sample values
    print("\nSample Status values (first 20):")
    for idx, val in enumerate(df_raw['Status'].head(20)):
        print(f"  {idx+1}. '{val}'")
else:
    print("\n❌ 'Status' field NOT found")
    print("\nAvailable columns:")
    for col in df_raw.columns:
        print(f"  - {col}")

print("\n" + "=" * 60)