"""
System Test Script
Validates database connection and data processing
"""
from database import DatabaseHandler
from data_processor import DataProcessor
from config import Config

def main():
    print("="*60)
    print("🔧 ZATCA Finance Dashboard - System Test")
    print("="*60)
    
    # 1. Validate configuration
    print("\n1️⃣ Validating configuration...")
    try:
        Config.validate()
    except Exception as e:
        print(f"❌ Configuration error: {e}")
        return
    
    # 2. Test database connection
    print("\n2️⃣ Testing database connection...")
    db = DatabaseHandler()
    
    if not db.connect():
        print("❌ Cannot connect to MongoDB. Exiting.")
        return
    
    # 3. Get collection stats
    print("\n3️⃣ Database statistics:")
    stats = db.get_collection_stats()
    for key, value in stats.items():
        print(f"   - {key}: {value:,}" if isinstance(value, int) else f"   - {key}: {value}")
    
    # 4. Load and process data
    print("\n4️⃣ Loading invoices...")
    df_raw = db.get_invoices()
    
    if df_raw.empty:
        print("❌ No data found")
        db.close()
        return
    
    print(f"\n   Raw data shape: {df_raw.shape}")
    print(f"   Columns: {df_raw.shape[1]}")
    print(f"   Rows: {df_raw.shape[0]:,}")
    
    # 5. Clean data
    print("\n5️⃣ Cleaning data...")
    processor = DataProcessor()
    df_clean = processor.clean_invoices(df_raw)
    
    # 6. Engineer features
    print("\n6️⃣ Engineering features...")
    df_features = processor.engineer_features(df_clean)
    
    # 7. Show sample processed data
    print("\n7️⃣ Sample processed invoice:")
    sample_cols = [
        'INVOICE_ID',
        'CUSTOMER_PARTY_LEGAL_ENTITY_REGISTRATION_NAME',
        'PAYABLE_AMOUNT_VALUE',
        'ISSUE_DATE',
        'DUE_DATE',
        'DAYS_UNTIL_DUE',
        'Status',
        'IS_PAID',
        'IS_LATE'
    ]
    
    print(df_features[sample_cols].head(3).to_string())
    
    # 8. Payment status summary
    print("\n8️⃣ Payment Status Summary:")
    print(df_features['Status'].value_counts())
    
    # 9. Close connection
    print("\n9️⃣ Closing connection...")
    db.close()
    
    print("\n" + "="*60)
    print("✅ SYSTEM TEST COMPLETED SUCCESSFULLY")
    print("="*60)
    print("\nNext step: Run 'streamlit run app.py' to launch dashboard")

if __name__ == "__main__":
    main()