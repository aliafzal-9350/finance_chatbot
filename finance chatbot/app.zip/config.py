"""
Configuration Management
Loads environment variables and business rules
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class Config:
    """Application configuration"""

    # MongoDB Settings (READ-ONLY)
    MONGO_URI = os.getenv("MONGO_URI")  # required, no hardcoded secret
    DATABASE_NAME = os.getenv("DATABASE_NAME", "Zatca")
    INVOICE_COLLECTION = os.getenv("INVOICE_COLLECTION", "ZATCA_API_INVOICES_ALL")
    LINE_ITEMS_COLLECTION = os.getenv("LINE_ITEMS_COLLECTION", "ZATCA_API_INVOICES_LINES_ALL")

    # Business Rules (Saudi ZATCA Standards)
    DEFAULT_PAYMENT_TERMS_DAYS = int(os.getenv("DEFAULT_PAYMENT_TERMS_DAYS", 30))
    LATE_PAYMENT_RISK_THRESHOLD = int(os.getenv("LATE_PAYMENT_RISK_THRESHOLD", 70))
    CURRENCY = os.getenv("CURRENCY", "SAR")

    # Model Settings
    RANDOM_STATE = 42
    TEST_SIZE = 0.2

    # Dashboard Settings
    PAGE_TITLE = "AI Finance Control Center"
    LAYOUT = "wide"

    @staticmethod
    def validate():
        """Validate configuration"""
        required = {
            "MONGO_URI": Config.MONGO_URI,
            "DATABASE_NAME": Config.DATABASE_NAME,
            "INVOICE_COLLECTION": Config.INVOICE_COLLECTION,
        }

        missing = [key for key, value in required.items() if not value]
        if missing:
            raise ValueError(
                f"Missing required configuration: {', '.join(missing)}. Check your .env file."
            )

        print("✅ Configuration validated successfully")